package com.vote.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
