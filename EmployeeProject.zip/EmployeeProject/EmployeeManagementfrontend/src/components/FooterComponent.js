import React, { Component } from 'react';
import '../App.css'; // Import custom CSS

export default class FooterComponent extends Component {
  render() {
    return (
      <div className="main-content">
      <footer className="footer-container">
        <span className="footer-text">All Rights Reserved 2024 &copy; Kunta Sravan Kumar</span>
      </footer></div>
    );
  }
}
